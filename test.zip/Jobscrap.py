import sys
import pandas as pd
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.wait import WebDriverWait
from openpyxl import load_workbook
pd.option_context('display.max_colwidth', 0)

options = webdriver.ChromeOptions()
# options.add_argument("user-agent=Chrome/87.0.4280.88")
# options.add_argument('headless')
# options.add_argument('--window-size=1920,1080')
driver = webdriver.Chrome(executable_path="D:\Drivers\chromedriver.exe", options=options)
# driver.delete_all_cookies()
for i in range(1,len(sys.argv)):
    if sys.argv[i] == 'Selenium':
        url = 'https://www.glassdoor.com/Job/selenium-jobs-SRCH_KO0,8.htm?&jobType=fulltime&fromAge=1&includeNoSalaryJobs=true'

driver.get(url)
start_time = time.time()
driver.maximize_window()

# # time.sleep(2)
# WebDriverWait(driver, 50).until(ec.presence_of_element_located((By.XPATH, '//*[@id="SiteNav"]/nav/div[2]/div/div/div/button')))
# driver.implicitly_wait(2)
# driver.find_element_by_xpath("//*[@id='SiteNav']/nav/div[2]/div/div/div/button").click()
# time.sleep(2)
# # to close the pop up window which appears at Login
# isAvailable = len(driver.find_elements_by_xpath("//*[@id='qual_ol']"))
# if isAvailable > 0:
#     print('yes')
#     if driver.find_element_by_xpath("//*[@id='qual_ol']").is_displayed():
#         driver.find_element_by_xpath("//*[@id='qual_ol']/div[1]").click()
# else:
#     print('no')
#
# driver.find_element_by_xpath("//*[@id='userEmail']").send_keys('sukanya.ravinder@gmail.com')
# time.sleep(1)
# isAvailable = len(driver.find_elements_by_xpath("//*[@id='qual_ol']"))
# if isAvailable > 0:
#     print('yes')
#     if driver.find_element_by_xpath("//*[@id='qual_ol']").is_displayed():
#         driver.find_element_by_xpath("//*[@id='qual_ol']/div[1]").click()
# else:
#     print('no')
#
# if isAvailable > 0:
#     print('yes')
#     if driver.find_element_by_xpath("//*[@id='qual_ol']").is_displayed():
#         driver.find_element_by_xpath("//*[@id='qual_ol']/div[1]").click()
# else:
#     print('no')
# driver.find_element_by_xpath("//*[@id='userPassword']").send_keys('India@123')
# driver.find_element_by_xpath(
#     "//*[@id='LoginModal']/div/div/div[2]/div[2]/div[2]/div/div/div/div[3]/form/div[3]/div[1]/button").click()
#
#     try:
#     # time.sleep(3)
#         WebDriverWait(driver, 50).until(ec.presence_of_element_located((By.XPATH, '//*[@id="sc.keyword"]')))
#         driver.find_element_by_xpath("//*[@id='sc.keyword']").send_keys(Keys.CONTROL, 'a')
#         driver.find_element_by_xpath("//*[@id='sc.keyword']").send_keys(Keys.BACKSPACE)
#         driver.find_element_by_xpath("//*[@id='sc.keyword']").send_keys(sys.argv[i])
#     except NoSuchElementException:
#         print('no element found')
#
#     try:
#         WebDriverWait(driver, 50).until(ec.presence_of_element_located((By.XPATH, '//*[@id="sc.location"]')))
#         driver.find_element_by_xpath("//*[@id='sc.location']").send_keys(Keys.CONTROL, 'a')
#         driver.find_element_by_xpath("//*[@id='sc.location']").send_keys(Keys.BACKSPACE)
#     except NoSuchElementException:
#         print('no element found')
#
#     try:
#         WebDriverWait(driver, 50).until(ec.presence_of_element_located((By.XPATH, '//*[@id="scBar"]/div/button')))
#         driver.find_element_by_xpath("//*[@id='scBar']/div/button").click()
#     except NoSuchElementException:
#         print('no element found')
#
#     try:
#         WebDriverWait(driver, 50).until(
#         ec.presence_of_element_located((By.XPATH, '//*[@id="Discover"]/div/div/div[1]/div[1]/div[3]/a')))
#         driver.find_element_by_xpath("//*[@id='Discover']/div/div/div[1]/div[1]/div[3]/a").click()
#     except NoSuchElementException:
#         print('no element found')
#
#     try:
#         WebDriverWait(driver, 50).until(ec.presence_of_element_located((By.XPATH, '//*[@id="filter_jobType"]')))
#         # time.sleep(5)
#         driver.find_element_by_xpath("//*[@id='filter_jobType']").click()
#     except NoSuchElementException:
#         print('no element found')
#     time.sleep(2)
#
#     try:
#         dp1 = WebDriverWait(driver, 50).until(ec.presence_of_element_located((By.XPATH, '//*[@id="PrimaryDropdown"]/ul/li[2]')))
#         # time.sleep(5)
#         dp1.click()
#     except NoSuchElementException:
#         print('no element found')
#
#     try:
#         dp2 = WebDriverWait(driver, 50).until(ec.presence_of_element_located((By.XPATH, '//*[@id="filter_fromAge"]')))
#         # time.sleep(5)
#         dp2.click()
#     except NoSuchElementException:
#         print('no element found')
#
#     try:
#         WebDriverWait(driver, 50).until(ec.presence_of_element_located((By.XPATH, '//*[@id="PrimaryDropdown"]/ul/li[2]')))
#         # time.sleep(5)
#         driver.find_element_by_xpath("//*[@id='PrimaryDropdown']/ul/li[2]").click()
#     except NoSuchElementException:
#         print('no element found')

time.sleep(1)
myElement = driver.find_elements_by_xpath('//*[@id="MainCol"]/div[1]/div[2]/div/div[1]/p')
if len(myElement) != 0:
    print(myElement[0].text)
else:
    m = driver.find_element_by_xpath("//*[@id='MainCol']/div[2]/div[1]").text
    numPages = int(m.split(' ')[3])
    isAvailable = len(driver.find_elements_by_xpath("//*[@id='JAModal']/div/div[2]"))
    if isAvailable > 0:
       print('yes')
       if driver.find_element_by_xpath("//*[@id='JAModal']/div/div[2]").is_displayed():
         driver.find_element_by_xpath("//*[@id='JAModal']/div/div[2]/span").click()
       else:
          print('no')

    iPage: int = 1
    jobs = []
    while iPage <= numPages:
       print(driver.find_element_by_xpath("//*[@id='MainCol']/div[2]/div[1]").text)
       job_buttons = driver.find_elements_by_xpath("//*[@id='MainCol']/div[1]/ul/li")
       num_jobs = len(job_buttons)
       if iPage == 1:
          total_jobs = len(jobs)
       else:
          total_jobs = total_jobs + len(jobs)

       if job_buttons != 0:
          msg = "{0} jobs available."
          print(msg.format(num_jobs))
          myElem = WebDriverWait(driver, 50).until(ec.presence_of_element_located((By.XPATH, '//*[@id="MainCol"]')))
          print('Page is ready')
          # driver.find_element_by_xpath('//*[@id="MainCol"]').click()
          for i in range(num_jobs):
               print("Progress: {}".format("" + str(i) + "/" + str(num_jobs)))

               # jobs.append('Hi')
               isAvailable = len(driver.find_elements_by_xpath("//*[@id='JAModal']/div/div[2]"))
               if isAvailable > 0:
                   print('yes popup')
                   if driver.find_element_by_xpath("//*[@id='JAModal']/div/div[2]").is_displayed():
                      driver.find_element_by_xpath("//*[@id='JAModal']/div/div[2]/span").click()
                   else:
                       print('no popup')
               job_link = job_buttons[i].find_element_by_xpath('.//div/a').get_attribute(
                  'href')
               print('Job Link: ' + job_link)
               jobId = job_buttons[i].get_attribute('data-id')
               print('JobId: ' + jobId)
               job_buttons[i].click()

               WebDriverWait(driver, 50).until(ec.presence_of_element_located((By.CLASS_NAME, 'css-vwxtm')))
               JobInfo = driver.find_element_by_class_name("css-vwxtm")

               section = JobInfo.find_element_by_class_name("css-19txzrf")

               # print(section.get_attribute("innerHTML"))
               company = section.find_element_by_class_name("css-87uc0g").get_attribute("innerText")
               # print('Company: ' + company)
               title = section.find_element_by_class_name("css-1vg6q84").get_attribute("innerText")
               # print('Job Title: ' + title)
               location = section.find_element_by_class_name("css-56kyx5").get_attribute("innerText")
               # print(location)

               JobDesc = driver.find_element_by_class_name("css-1bqnmih")
               elementsList = JobDesc.find_element_by_class_name("jobDescriptionContent").find_elements_by_xpath("./*")
               jobDetails = ""
               for i in range(len(elementsList)):
                   if(i<=10):
                     jobDetails = jobDetails + elementsList[i].get_attribute("innerText")
               print(jobDetails)
                    # jobDetails = JobDesc.find_element_by_class_name("jobDescriptionContent").get_attribute("innerText")

               jobs.append({"Job Id": jobId, "Job Title": title, "Company Name": company,
                             "Location": location, "Job Description": jobDetails,"Job Link": job_link})

               isAvailable = len(driver.find_elements_by_xpath("//*[@id='JAModal']/div/div[2]"))
               if isAvailable > 0:
                  print('yes popup')
                  if driver.find_element_by_xpath("//*[@id='JAModal']/div/div[2]").is_displayed():
                     driver.find_element_by_xpath("//*[@id='JAModal']/div/div[2]/span").click()
               else:
                print('no popup')
               nCnt: int = len(
               driver.find_elements_by_xpath("//*[@id='FooterPageNav']/div/ul/li[contains(@class, 'css-114lpwu')]"))
          if nCnt > 0:
            bNext = True
            print('Next is available')
            driver.find_element_by_xpath("//*[@id='FooterPageNav']/div/ul/li[contains(@class, 'css-114lpwu')]").click()
            print('Clicking Next Button')
            time.sleep(2)
            isAvailable = len(driver.find_elements_by_xpath("//*[@id='JAModal']/div/div[2]"))
            if isAvailable > 0:
               print('yes popup')
               if driver.find_element_by_xpath("//*[@id='JAModal']/div/div[2]").is_displayed():
                  driver.find_element_by_xpath("//*[@id='JAModal']/div/div[2]/span").click()
            else:
                print('no popup')
          else:
            bNext = False
            break
       iPage = iPage + 1
    total_jobs = len(jobs)
    print('Total jobs scrapped: ' + str(total_jobs))
    print('End of Jobs')

    print("--- %s seconds ---" % (time.time() - start_time))

    df = pd.DataFrame(jobs)

    df['Job Id'] = df['Job Id'].str.strip()
    df['Job Title'] = df['Job Title'].str.strip()
    df['Company Name'] = df['Company Name'].str.strip()
    df['Location'] = df['Location'].str.strip()
    df['Job Description'] = df['Job Description'].str.strip()
    df['Job Link'] = df['Job Link'].str.strip()

    print(df)
        # df.to_csv('my_csv.csv', mode='a', header=False)

    book = load_workbook('C:/Users/Sukanya Ruthvik/PycharmProjects/JobScrappingProject/test.xlsx')
    writer = pd.ExcelWriter('C:/Users/Sukanya Ruthvik/PycharmProjects/JobScrappingProject/test.xlsx', engine='openpyxl')
    writer.book = book
    writer.sheets = {ws.title: ws for ws in book.worksheets}
    for sheetname in writer.sheets:
            # print(writer.sheets[sheetname].max_row)
        if writer.sheets[sheetname].max_row == 1:
            df.to_excel(writer, sheet_name=sheetname, startrow=writer.sheets[sheetname].max_row, index=False, header=True)
        else:
            df.to_excel(writer,sheet_name=sheetname, startrow=writer.sheets[sheetname].max_row, index = False,header= False)
    writer.save()
# driver.close()
# driver.quit()
# df.to_excel('D:\df.xlsx')
